
function ProductsNew() {
  return (
    <div>ProductsNew</div>
  )
}

export default ProductsNew